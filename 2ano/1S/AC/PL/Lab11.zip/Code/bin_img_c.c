void bin_img_c(unsigned char *ptr, int w, int h)
{
/* ... */
}