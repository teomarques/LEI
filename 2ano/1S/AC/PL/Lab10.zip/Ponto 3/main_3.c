#include <stdio.h>
#include "mdc.h"

void main(){
	
	int val = mdc(48,18);
	
	printf("O mdc entre 18 e 48 é %d\n",val);
}