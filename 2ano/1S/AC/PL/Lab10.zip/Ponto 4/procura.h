// protótipo da função procura

int procura(int *tab, int low, int high, int num);